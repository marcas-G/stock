#!/usr/bin/env python3
"""遍历夸克分享目录树,生成最近 N 个交易日的目标股票 manifest(全量)。

树结构:
  level2_detail/level2按个股压缩--历史数据增加中/{年}/{月}/{日}/{前缀}/{4位组}/{股票}.zip

搜索接口(share/file/search)索引不完整(000333 只有 8 个),所以必须走目录树。

用法:python3 build_manifest_tree.py [交易日数] [out_json]
默认 250 天 -> manifest_tree_250d.json
"""
import json
import os
import sys
import time
import urllib.parse
import urllib.request
import urllib.error
from concurrent.futures import ThreadPoolExecutor, as_completed

PWD_ID = "1ae1c55c0a03"
PASSCODE = "QNhy"
COOKIES = open("/tmp/quark_cookies.txt").read().strip()
UA = ("Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 "
      "(KHTML, like Gecko) Chrome/151.0.0.0 Safari/537.36")
HOST_PC = "https://drive-pc.quark.cn/1/clouddrive"
CODES_FILE = "codes_300.txt"

# 代码前缀 -> 树中前缀目录名
def prefix_of(code):
    if code.startswith(("000", "001", "002", "003")):
        return "00开头"
    if code.startswith(("300", "301")):
        return "30开头"
    if code.startswith(("600", "601", "603", "605")):
        return "60开头"
    if code.startswith("688"):
        return "68开头"
    return None  # 其余不覆盖


def http(url, body=None, retry=3, timeout=60):
    headers = {
        "Content-Type": "application/json",
        "Accept": "application/json, text/plain, */*",
        "Referer": "https://pan.quark.cn/",
        "User-Agent": UA,
        "Origin": "https://pan.quark.cn",
        "Cookie": COOKIES,
    }
    data = json.dumps(body).encode() if body is not None else None
    last = None
    for attempt in range(retry):
        req = urllib.request.Request(url, data=data, headers=headers)
        try:
            with urllib.request.urlopen(req, timeout=timeout) as r:
                return r.status, json.loads(r.read().decode())
        except urllib.error.HTTPError as e:
            try:
                last = (e.code, json.loads(e.read().decode()))
            except Exception:
                last = (e.code, None)
            if e.code in (401, 403):
                break
        except Exception as ex:
            last = (0, str(ex))
            if attempt == retry - 1:
                break
            time.sleep(2 * (attempt + 1))
    return last if last else (0, None)


def get_stoken():
    s, r = http(f"{HOST_PC}/share/sharepage/token",
                {"pwd_id": PWD_ID, "passcode": PASSCODE})
    assert s == 200 and r and r.get("status") == 200, f"token failed: {r}"
    return r["data"]["stoken"]


def detail(stoken, pdir, page=1, size=50):
    url = (f"{HOST_PC}/share/sharepage/detail?ver=2&pwd_id={PWD_ID}"
           f"&stoken={urllib.parse.quote(stoken, safe='')}"
           f"&pdir_fid={pdir}&force=0&_page={page}&_size={size}"
           f"&_fetch_total=1&_sort=")
    s, r = http(url)
    if s != 200 or not r or r.get("status") != 200:
        return []
    return (r.get("data") or {}).get("list") or []


def list_all(stoken, pdir):
    """翻页列出目录下全部条目"""
    items, page = [], 1
    while True:
        lst = detail(stoken, pdir, page, 50)
        if not lst:
            break
        items += lst
        if len(lst) < 50:
            break
        page += 1
        time.sleep(0.05)
    return items


def main():
    n_days = int(sys.argv[1]) if len(sys.argv) > 1 else 250
    out_json = sys.argv[2] if len(sys.argv) > 2 else "manifest_tree_250d.json"

    codes = open(CODES_FILE).read().split()
    codes = sorted(set(codes))
    # 代码 -> (前缀名, 4位组名)
    need = {}
    for c in codes:
        p = prefix_of(c)
        if p:
            need.setdefault(p, []).append(c)
    print(f"{len(codes)} 只目标股票, 涉及前缀 {sorted(need)}")

    stoken = get_stoken()

    # 1) 定位 level2按个股压缩--历史数据增加中
    root = list_all(stoken, "")
    lv2 = next(it for it in root if it["file_name"] == "level2_detail")
    l2 = list_all(stoken, lv2["fid"])
    sd = next(it for it in l2 if "个股压缩" in it["file_name"])
    print("个股压缩目录:", sd["file_name"], sd["fid"][:8])

    # 2) 收集全部日期目录 {date: fid}
    dates = {}
    years = list_all(stoken, sd["fid"])
    for y in years:
        months = list_all(stoken, y["fid"])
        for m in months:
            days = list_all(stoken, m["fid"])
            for d in days:
                dates[d["file_name"]] = d["fid"]
    all_dates = sorted(dates)
    recent = all_dates[-n_days:]
    print(f"全分享日期 {len(all_dates)} 个({all_dates[0]}~{all_dates[-1]}), "
          f"取最近 {len(recent)} 个({recent[0]}~{recent[-1]})")

    # 3) 按 (日期, 前缀) 并发遍历
    manifest = []
    lock = __import__("threading").Lock()

    def scan_day_prefix(day_fid, day, prefix, codes_in_prefix):
        # 返回该 (日期, 前缀) 下命中的条目
        got = []
        prefs = list_all(stoken, day_fid)
        p = next((it for it in prefs if it["file_name"] == prefix), None)
        if not p:
            return got
        groups = list_all(stoken, p["fid"])
        by_group = {}
        for c in codes_in_prefix:
            by_group.setdefault(c[:4], []).append(c)
        for gname, ccodes in by_group.items():
            g = next((it for it in groups if it["file_name"] == gname), None)
            if not g:
                continue
            files = list_all(stoken, g["fid"])
            for f in files:
                fn = f["file_name"]
                for c in ccodes:
                    if fn in (f"{c}.SZ.zip", f"{c}.SH.zip"):
                        got.append({
                            "code": c, "file": fn, "path": f"{day}/{c}/{fn}",
                            "date": day, "size": f.get("size", 0),
                            "fid": f["fid"], "pdir_fid": g["fid"],
                        })
                        break
        return got

    tasks = []
    for day in recent:
        for prefix, ccodes in need.items():
            tasks.append((dates[day], day, prefix, ccodes))

    done = 0
    with ThreadPoolExecutor(max_workers=8) as ex:
        futs = {ex.submit(scan_day_prefix, *t): t for t in tasks}
        for f in as_completed(futs):
            for e in f.result():
                with lock:
                    manifest.append(e)
            done += 1
            if done % 200 == 0:
                print(f"  {done}/{len(tasks)} 任务完成, 命中 {len(manifest)}", flush=True)

    manifest.sort(key=lambda e: (e["date"], e["code"]))
    with open(out_json, "w", encoding="utf-8") as f:
        json.dump(manifest, f, ensure_ascii=False, indent=1)
    total = sum(e["size"] for e in manifest)
    codes_hit = sorted(set(e["code"] for e in manifest))
    print(f"\nmanifest -> {out_json}: {len(manifest)} 文件, {total/1e9:.2f} GB")
    print(f"覆盖股票 {len(codes_hit)}/{len(codes)}, 日期 {len(set(e['date'] for e in manifest))}")
    miss = sorted(set(codes) - set(codes_hit))
    if miss:
        print("未命中股票:", miss)


if __name__ == "__main__":
    main()
